import React, { useEffect, useRef, useState } from 'react';
import { TrendingUp, TrendingDown, Minus, RotateCcw, Clock, CheckCircle, XCircle } from 'lucide-react';
import './index.css';

interface PredictionHistory {
  id: string;
  timestamp: Date;
  scenario: string;
  direction: 'up' | 'down' | 'sideways';
  confidence: number;
  currentPrice: number;
  predictedPrice: number;
  change: number;
  status: 'pending' | 'won' | 'lost';
  actualPrice?: number;
  actualChange?: number;
  timeRemaining?: number;
}

interface HistoricalDataPoint {
  date: Date;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

const App: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>();
  const timerRef = useRef<NodeJS.Timeout>();
  const [currentScenario, setCurrentScenario] = useState(0);
  const [predictionHistory, setPredictionHistory] = useState<PredictionHistory[]>([]);
  const [isManualMode, setIsManualMode] = useState(false);
  const [lastPrediction, setLastPrediction] = useState<PredictionHistory | null>(null);
  const [currentPrice, setCurrentPrice] = useState(185.50);
  const [countdownActive, setCountdownActive] = useState(false);
  const [historicalData, setHistoricalData] = useState<HistoricalDataPoint[]>([]);
  const [countdownSeconds, setCountdownSeconds] = useState(0);

  // Generate realistic year-long historical data
  useEffect(() => {
    const generateYearData = () => {
      const data: HistoricalDataPoint[] = [];
      const startDate = new Date();
      startDate.setFullYear(startDate.getFullYear() - 1);
      
      let basePrice = 120; // Starting price a year ago
      const daysInYear = 365;
      
      // Market trends throughout the year
      const trends = [
        { start: 0, end: 60, trend: 0.0008, volatility: 0.015 }, // Q1 - Slow growth
        { start: 60, end: 120, trend: 0.0015, volatility: 0.020 }, // Q2 - Bull market
        { start: 120, end: 200, trend: -0.0005, volatility: 0.025 }, // Q3 - Correction
        { start: 200, end: 280, trend: 0.0012, volatility: 0.018 }, // Q4 - Recovery
        { start: 280, end: 365, trend: 0.0010, volatility: 0.016 }  // Recent - Steady growth
      ];
      
      for (let i = 0; i < daysInYear; i++) {
        const currentDate = new Date(startDate);
        currentDate.setDate(startDate.getDate() + i);
        
        // Find current trend period
        const currentTrend = trends.find(t => i >= t.start && i < t.end) || trends[0];
        
        // Apply trend and volatility
        const trendChange = basePrice * currentTrend.trend;
        const volatilityChange = (Math.random() - 0.5) * currentTrend.volatility * basePrice;
        const dailyChange = trendChange + volatilityChange;
        
        // Add some market events (earnings, news, etc.)
        let eventMultiplier = 1;
        if (Math.random() < 0.05) { // 5% chance of significant event
          eventMultiplier = Math.random() < 0.5 ? 1.03 : 0.97; // +/-3% event
        }
        
        const open = basePrice;
        const close = (basePrice + dailyChange) * eventMultiplier;
        
        // Generate realistic high/low based on volatility
        const dayRange = Math.abs(close - open) + (Math.random() * 0.02 * basePrice);
        const high = Math.max(open, close) + (Math.random() * dayRange * 0.5);
        const low = Math.min(open, close) - (Math.random() * dayRange * 0.5);
        
        // Generate volume (higher on volatile days)
        const baseVolume = 1000000;
        const volatilityFactor = Math.abs(close - open) / open;
        const volume = Math.floor(baseVolume * (1 + volatilityFactor * 3) * (0.5 + Math.random()));
        
        data.push({
          date: new Date(currentDate),
          open: Math.max(open, 10),
          high: Math.max(high, 10),
          low: Math.max(low, 10),
          close: Math.max(close, 10),
          volume
        });
        
        basePrice = close;
      }
      
      return data;
    };

    const yearData = generateYearData();
    setHistoricalData(yearData);
    
    // Set current price based on last historical data point
    if (yearData.length > 0) {
      setCurrentPrice(yearData[yearData.length - 1].close);
    }
  }, []);

  // Update current price simulation with more realistic movements
  useEffect(() => {
    const priceInterval = setInterval(() => {
      setCurrentPrice(prev => {
        // More realistic intraday volatility
        const volatility = 0.001; // 0.1% typical movement
        const change = (Math.random() - 0.5) * volatility * prev;
        
        // Add some momentum (trending behavior)
        const momentum = Math.sin(Date.now() / 10000) * 0.0005 * prev;
        
        return Math.max(prev + change + momentum, 10); // Minimum price of $10
      });
    }, 1000);

    return () => clearInterval(priceInterval);
  }, []);

  // Countdown timer for active prediction (15 seconds)
  useEffect(() => {
    if (countdownActive && lastPrediction && lastPrediction.status === 'pending') {
      setCountdownSeconds(15);
      
      const countdownInterval = setInterval(() => {
        setCountdownSeconds(prev => {
          if (prev <= 1) {
            // Time's up - evaluate prediction
            evaluatePrediction(lastPrediction, currentPrice);
            setCountdownActive(false);
            clearInterval(countdownInterval);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      // Update prediction history with countdown
      const updateHistory = setInterval(() => {
        setPredictionHistory(prev => 
          prev.map(p => 
            p.id === lastPrediction.id 
              ? { ...p, timeRemaining: countdownSeconds }
              : p
          )
        );

        setLastPrediction(prev => 
          prev ? { ...prev, timeRemaining: countdownSeconds } : null
        );
      }, 100);

      return () => {
        clearInterval(countdownInterval);
        clearInterval(updateHistory);
      };
    }
  }, [countdownActive, lastPrediction]);

  // Update prediction objects with current countdown
  useEffect(() => {
    if (countdownActive && lastPrediction) {
      setPredictionHistory(prev => 
        prev.map(p => 
          p.id === lastPrediction.id 
            ? { ...p, timeRemaining: countdownSeconds }
            : p
        )
      );

      setLastPrediction(prev => 
        prev ? { ...prev, timeRemaining: countdownSeconds } : null
      );
    }
  }, [countdownSeconds, countdownActive, lastPrediction]);

  const evaluatePrediction = (prediction: PredictionHistory, actualPrice: number) => {
    const actualChange = (actualPrice - prediction.currentPrice) / prediction.currentPrice;
    const predictedChange = prediction.change;
    
    let won = false;
    
    // Determine if prediction was correct based on direction
    if (prediction.direction === 'up') {
      won = actualChange > 0.005; // At least 0.5% increase
    } else if (prediction.direction === 'down') {
      won = actualChange < -0.005; // At least 0.5% decrease
    } else { // sideways
      won = Math.abs(actualChange) <= 0.01; // Within 1% range
    }

    const updatedPrediction = {
      ...prediction,
      status: won ? 'won' as const : 'lost' as const,
      actualPrice,
      actualChange,
      timeRemaining: 0
    };

    setPredictionHistory(prev => 
      prev.map(p => p.id === prediction.id ? updatedPrediction : p)
    );

    setLastPrediction(updatedPrediction);

    // Show result notification
    setTimeout(() => {
      alert(`Prediction ${won ? 'WON' : 'LOST'}!\nExpected: ${(prediction.change * 100).toFixed(1)}%\nActual: ${(actualChange * 100).toFixed(1)}%`);
    }, 100);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || historicalData.length === 0) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const resizeCanvas = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * window.devicePixelRatio;
      canvas.height = rect.height * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Use last 90 days for display
    const displayData = historicalData.slice(-90);
    const currentData = {
      open: currentPrice * 0.999,
      high: currentPrice * 1.002,
      low: currentPrice * 0.998,
      close: currentPrice
    };

    // Prediction scenarios based on historical patterns
    const recentTrend = displayData.length > 5 ? 
      (displayData[displayData.length - 1].close - displayData[displayData.length - 6].close) / displayData[displayData.length - 6].close : 0;
    
    const predictionScenarios = [
      {
        name: 'Bullish',
        direction: 'up' as const,
        color: '#22c55e',
        confidence: Math.floor(65 + Math.random() * 20),
        points: [
          { price: currentPrice, change: 0 },
          { price: currentPrice * 1.02, change: 0.02 },
          { price: currentPrice * 1.05, change: 0.05 },
          { price: currentPrice * 1.08, change: 0.08 }
        ]
      },
      {
        name: 'Bearish',
        direction: 'down' as const,
        color: '#ef4444',
        confidence: Math.floor(60 + Math.random() * 25),
        points: [
          { price: currentPrice, change: 0 },
          { price: currentPrice * 0.98, change: -0.02 },
          { price: currentPrice * 0.95, change: -0.05 },
          { price: currentPrice * 0.92, change: -0.08 }
        ]
      },
      {
        name: 'Sideways',
        direction: 'sideways' as const,
        color: '#3b82f6',
        confidence: Math.floor(70 + Math.random() * 15),
        points: [
          { price: currentPrice, change: 0 },
          { price: currentPrice * 1.01, change: 0.01 },
          { price: currentPrice * 0.99, change: -0.01 },
          { price: currentPrice * 1.005, change: 0.005 }
        ]
      }
    ];

    // Animation state
    let scenarioStartTime = Date.now();
    let currentPulse = 0;
    let ohlcFlicker = 0;

    // Helper functions
    const drawCandlestick = (x: number, y: number, width: number, candle: any, colors: any) => {
      const { open, high, low, close } = candle;
      const minPrice = Math.min(...displayData.map(d => d.low)) * 0.98;
      const maxPrice = Math.max(...displayData.map(d => d.high)) * 1.02;
      const priceRange = maxPrice - minPrice;

      const openY = y + (maxPrice - open) / priceRange * 200;
      const closeY = y + (maxPrice - close) / priceRange * 200;
      const highY = y + (maxPrice - high) / priceRange * 200;
      const lowY = y + (maxPrice - low) / priceRange * 200;

      const isGreen = close > open;
      const color = isGreen ? colors.green : colors.red;

      // Draw wick
      ctx.strokeStyle = color;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x + width / 2, highY);
      ctx.lineTo(x + width / 2, lowY);
      ctx.stroke();

      // Draw body
      ctx.fillStyle = color;
      const bodyHeight = Math.abs(closeY - openY);
      const bodyY = Math.min(openY, closeY);
      
      if (bodyHeight < 2) {
        ctx.fillRect(x, bodyY - 1, width, 2);
      } else {
        ctx.fillRect(x, bodyY, width, bodyHeight);
      }
    };

    const drawPanel = (x: number, y: number, width: number, height: number, title: string) => {
      ctx.strokeStyle = '#374151';
      ctx.lineWidth = 1;
      ctx.strokeRect(x, y, width, height);

      ctx.fillStyle = '#f9fafb';
      ctx.font = '12px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(title, x + width / 2, y - 10);
    };

    const drawDirectionIndicator = (x: number, y: number, scenario: any) => {
      const iconSize = 24;
      const iconX = x + 10;
      const iconY = y + 10;

      ctx.fillStyle = scenario.color;
      ctx.font = 'bold 16px Inter, sans-serif';
      ctx.textAlign = 'left';

      // Draw direction arrow/icon
      if (scenario.direction === 'up') {
        // Draw up arrow
        ctx.beginPath();
        ctx.moveTo(iconX + iconSize/2, iconY);
        ctx.lineTo(iconX + iconSize, iconY + iconSize);
        ctx.lineTo(iconX, iconY + iconSize);
        ctx.closePath();
        ctx.fill();
        ctx.fillText('↗ BULLISH', iconX + iconSize + 10, iconY + iconSize/2 + 5);
      } else if (scenario.direction === 'down') {
        // Draw down arrow
        ctx.beginPath();
        ctx.moveTo(iconX, iconY);
        ctx.lineTo(iconX + iconSize, iconY);
        ctx.lineTo(iconX + iconSize/2, iconY + iconSize);
        ctx.closePath();
        ctx.fill();
        ctx.fillText('↘ BEARISH', iconX + iconSize + 10, iconY + iconSize/2 + 5);
      } else {
        // Draw sideways line
        ctx.fillRect(iconX, iconY + iconSize/2 - 2, iconSize, 4);
        ctx.fillText('→ SIDEWAYS', iconX + iconSize + 10, iconY + iconSize/2 + 5);
      }
    };

    const animate = () => {
      const rect = canvas.getBoundingClientRect();
      ctx.clearRect(0, 0, rect.width, rect.height);

      const panelWidth = rect.width / 3;
      const panelHeight = 300;
      const panelY = 50;

      // Panel 1: Historical Data (Last 90 days)
      drawPanel(0, panelY, panelWidth - 10, panelHeight, 'HISTORICAL DATA (90 DAYS)');
      
      const candleWidth = (panelWidth - 20) / displayData.length;
      displayData.forEach((candle, i) => {
        drawCandlestick(
          i * candleWidth + 10,
          panelY + 20,
          candleWidth - 1,
          candle,
          { green: '#22c55e60', red: '#ef444460' }
        );
      });

      // Add price labels for historical data
      if (displayData.length > 0) {
        const minPrice = Math.min(...displayData.map(d => d.low)) * 0.98;
        const maxPrice = Math.max(...displayData.map(d => d.high)) * 1.02;
        
        ctx.fillStyle = '#64748b';
        ctx.font = '10px Inter, sans-serif';
        ctx.textAlign = 'right';
        ctx.fillText(`$${maxPrice.toFixed(0)}`, panelWidth - 15, panelY + 30);
        ctx.fillText(`$${minPrice.toFixed(0)}`, panelWidth - 15, panelY + 210);
        
        // Show year range
        const startDate = displayData[0].date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        const endDate = displayData[displayData.length - 1].date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        ctx.textAlign = 'center';
        ctx.fillText(`${startDate} - ${endDate}`, panelWidth / 2, panelY + panelHeight - 10);
      }

      // Panel 2: Current Trading
      currentPulse += 0.05;
      ohlcFlicker += 0.1;
      
      drawPanel(panelWidth, panelY, panelWidth - 10, panelHeight, 'CURRENT DAILY CANDLE');
      
      const pulseIntensity = 0.8 + 0.2 * Math.sin(currentPulse);
      const currentColors = {
        green: `rgba(34, 197, 94, ${pulseIntensity})`,
        red: `rgba(239, 68, 68, ${pulseIntensity})`
      };
      
      drawCandlestick(
        panelWidth + 20,
        panelY + 20,
        panelWidth - 60,
        currentData,
        currentColors
      );

      // OHLC values with flicker
      const flickerAlpha = 0.7 + 0.3 * Math.sin(ohlcFlicker);
      ctx.fillStyle = `rgba(249, 250, 251, ${flickerAlpha})`;
      ctx.font = '11px Inter, sans-serif';
      ctx.textAlign = 'left';
      
      const ohlcX = panelWidth + 10;
      const ohlcY = panelY + panelHeight - 80;
      
      ctx.fillText(`O: $${currentData.open.toFixed(2)}`, ohlcX, ohlcY);
      ctx.fillText(`H: $${currentData.high.toFixed(2)}`, ohlcX, ohlcY + 15);
      ctx.fillText(`L: $${currentData.low.toFixed(2)}`, ohlcX, ohlcY + 30);
      ctx.fillText(`C: $${currentData.close.toFixed(2)}`, ohlcX, ohlcY + 45);

      // Panel 3: Predictions
      const now = Date.now();
      if (!isManualMode && now - scenarioStartTime > 6000) {
        setCurrentScenario(prev => (prev + 1) % predictionScenarios.length);
        scenarioStartTime = now;
      }

      const scenario = predictionScenarios[currentScenario];
      const fadeProgress = Math.min((now - scenarioStartTime) / 1000, 1);
      
      drawPanel(panelWidth * 2, panelY, panelWidth - 10, panelHeight, 'PREDICTED TRAJECTORY');

      // Draw direction indicator
      drawDirectionIndicator(panelWidth * 2, panelY + 20, scenario);

      // Draw prediction line
      ctx.strokeStyle = scenario.color + '60';
      ctx.lineWidth = 3;
      ctx.beginPath();
      
      const predictionX = panelWidth * 2 + 10;
      const predictionWidth = panelWidth - 30;
      
      scenario.points.forEach((point, i) => {
        const x = predictionX + (i / (scenario.points.length - 1)) * predictionWidth;
        const y = panelY + 150 - point.change * 400;
        
        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });
      
      ctx.globalAlpha = fadeProgress * 0.8;
      ctx.stroke();
      ctx.globalAlpha = 1;

      // Prediction details
      ctx.fillStyle = '#f9fafb';
      ctx.font = '11px Inter, sans-serif';
      ctx.textAlign = 'center';
      const detailsX = panelWidth * 2 + panelWidth / 2;
      const detailsY = panelY + panelHeight - 80;
      
      ctx.fillText(`Confidence: ${scenario.confidence}%`, detailsX, detailsY);
      
      const finalPoint = scenario.points[scenario.points.length - 1];
      const changePercent = (finalPoint.change * 100).toFixed(1);
      const changeText = finalPoint.change > 0 ? `+${changePercent}%` : `${changePercent}%`;
      ctx.fillText(`Expected: ${changeText}`, detailsX, detailsY + 15);
      ctx.fillText(`Target: $${finalPoint.price.toFixed(2)}`, detailsX, detailsY + 30);
      ctx.fillText(`15-sec validation`, detailsX, detailsY + 45);

      animationFrameRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [currentScenario, isManualMode, currentPrice, historicalData]);

  const handlePredict = () => {
    if (countdownActive) return; // Prevent new predictions during countdown

    const scenarios = [
      { name: 'Bullish', direction: 'up' as const, confidence: Math.floor(65 + Math.random() * 20), multiplier: 1.08 },
      { name: 'Bearish', direction: 'down' as const, confidence: Math.floor(60 + Math.random() * 25), multiplier: 0.92 },
      { name: 'Sideways', direction: 'sideways' as const, confidence: Math.floor(70 + Math.random() * 15), multiplier: 1.005 }
    ];

    const randomScenario = scenarios[Math.floor(Math.random() * scenarios.length)];
    const predictedPrice = currentPrice * randomScenario.multiplier;
    const change = (predictedPrice - currentPrice) / currentPrice;

    const newPrediction: PredictionHistory = {
      id: Date.now().toString(),
      timestamp: new Date(),
      scenario: randomScenario.name,
      direction: randomScenario.direction,
      confidence: randomScenario.confidence,
      currentPrice,
      predictedPrice,
      change,
      status: 'pending',
      timeRemaining: 15
    };

    setPredictionHistory(prev => [newPrediction, ...prev.slice(0, 9)]);
    setLastPrediction(newPrediction);
    setCurrentScenario(scenarios.indexOf(randomScenario));
    setIsManualMode(true);
    setCountdownActive(true);
    setCountdownSeconds(15);
  };

  const handleReset = () => {
    setIsManualMode(false);
    setPredictionHistory([]);
    setLastPrediction(null);
    setCountdownActive(false);
    setCountdownSeconds(0);
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
  };

  const getDirectionIcon = (direction: string) => {
    switch (direction) {
      case 'up': return <TrendingUp className="w-4 h-4" />;
      case 'down': return <TrendingDown className="w-4 h-4" />;
      default: return <Minus className="w-4 h-4" />;
    }
  };

  const getDirectionColor = (direction: string) => {
    switch (direction) {
      case 'up': return 'text-green-400';
      case 'down': return 'text-red-400';
      default: return 'text-blue-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'won': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'lost': return <XCircle className="w-4 h-4 text-red-400" />;
      default: return <Clock className="w-4 h-4 text-yellow-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'won': return 'text-green-400';
      case 'lost': return 'text-red-400';
      default: return 'text-yellow-400';
    }
  };

  const winRate = predictionHistory.length > 0 
    ? (predictionHistory.filter(p => p.status === 'won').length / predictionHistory.filter(p => p.status !== 'pending').length * 100) || 0
    : 0;

  const totalPredictions = predictionHistory.filter(p => p.status !== 'pending').length;
  const wins = predictionHistory.filter(p => p.status === 'won').length;
  const losses = predictionHistory.filter(p => p.status === 'lost').length;

  return (
    <div className="predictive-canvas">
      <div className="header">
        <h1>The Predictive Canvas</h1>
        <p>Interactive Stock Market Prediction Validation</p>
        <div className="current-price">
          Current Price: <span className="price-value">${currentPrice.toFixed(2)}</span>
        </div>
        {historicalData.length > 0 && (
          <div className="year-performance">
            <span className="year-label">Year Performance: </span>
            <span className={`year-change ${historicalData[0].close < currentPrice ? 'text-green-400' : 'text-red-400'}`}>
              {((currentPrice - historicalData[0].close) / historicalData[0].close * 100).toFixed(1)}%
            </span>
            <span className="year-range">
              (${historicalData[0].close.toFixed(2)} → ${currentPrice.toFixed(2)})
            </span>
          </div>
        )}
      </div>
      
      <div className="canvas-container">
        <canvas
          ref={canvasRef}
          className="main-canvas"
          style={{ width: '100%', height: '400px' }}
        />
      </div>

      <div className="prediction-controls">
        <button 
          onClick={handlePredict}
          className={`predict-button ${countdownActive ? 'disabled' : ''}`}
          disabled={countdownActive}
        >
          <TrendingUp className="w-5 h-5" />
          {countdownActive ? 'Validating...' : 'Predict'}
        </button>
        
        <button 
          onClick={handleReset}
          className="reset-button"
          disabled={predictionHistory.length === 0}
        >
          <RotateCcw className="w-5 h-5" />
          Reset
        </button>

        {lastPrediction && (
          <div className="last-prediction">
            <div className={`prediction-badge ${getDirectionColor(lastPrediction.direction)}`}>
              {getDirectionIcon(lastPrediction.direction)}
              <span>{lastPrediction.scenario}</span>
              <span className="confidence">{lastPrediction.confidence}%</span>
              {lastPrediction.status === 'pending' && lastPrediction.timeRemaining !== undefined && (
                <span className="countdown">
                  <Clock className="w-3 h-3" />
                  {countdownSeconds}s
                </span>
              )}
              {lastPrediction.status !== 'pending' && (
                <span className={`status ${getStatusColor(lastPrediction.status)}`}>
                  {getStatusIcon(lastPrediction.status)}
                  {lastPrediction.status.toUpperCase()}
                </span>
              )}
            </div>
          </div>
        )}
      </div>

      {totalPredictions > 0 && (
        <div className="stats-panel">
          <div className="stat-item">
            <span className="stat-label">Win Rate</span>
            <span className={`stat-value ${winRate >= 50 ? 'text-green-400' : 'text-red-400'}`}>
              {winRate.toFixed(1)}%
            </span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Total Predictions</span>
            <span className="stat-value">{totalPredictions}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Wins</span>
            <span className="stat-value text-green-400">{wins}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Losses</span>
            <span className="stat-value text-red-400">{losses}</span>
          </div>
        </div>
      )}
      
      <div className="legend">
        <div className="legend-item">
          <div className="legend-color historical"></div>
          <span>Historical Data (365 days)</span>
        </div>
        <div className="legend-item">
          <div className="legend-color current"></div>
          <span>Current Trading</span>
        </div>
        <div className="legend-item">
          <div className="legend-color prediction"></div>
          <span>AI Predictions (15s validation)</span>
        </div>
      </div>

      {predictionHistory.length > 0 && (
        <div className="prediction-history">
          <h3>Prediction History</h3>
          <div className="history-grid">
            {predictionHistory.map((prediction) => (
              <div key={prediction.id} className={`history-item ${prediction.status}`}>
                <div className="history-header">
                  <div className={`history-direction ${getDirectionColor(prediction.direction)}`}>
                    {getDirectionIcon(prediction.direction)}
                    <span>{prediction.scenario}</span>
                  </div>
                  <div className="history-status">
                    {prediction.status === 'pending' && prediction.timeRemaining !== undefined ? (
                      <span className="countdown-badge">
                        <Clock className="w-3 h-3" />
                        {countdownSeconds}s
                      </span>
                    ) : (
                      <span className={`status-badge ${getStatusColor(prediction.status)}`}>
                        {getStatusIcon(prediction.status)}
                        {prediction.status.toUpperCase()}
                      </span>
                    )}
                  </div>
                </div>
                <div className="history-details">
                  <div className="history-price">
                    <span>Start: ${prediction.currentPrice.toFixed(2)}</span>
                    <span>Target: ${prediction.predictedPrice.toFixed(2)}</span>
                    {prediction.actualPrice && (
                      <span>Actual: ${prediction.actualPrice.toFixed(2)}</span>
                    )}
                  </div>
                  <div className="history-change">
                    <span className={prediction.change > 0 ? 'text-green-400' : 'text-red-400'}>
                      Expected: {prediction.change > 0 ? '+' : ''}{(prediction.change * 100).toFixed(1)}%
                    </span>
                    {prediction.actualChange !== undefined && (
                      <span className={prediction.actualChange > 0 ? 'text-green-400' : 'text-red-400'}>
                        Actual: {prediction.actualChange > 0 ? '+' : ''}{(prediction.actualChange * 100).toFixed(1)}%
                      </span>
                    )}
                    <span className="history-confidence">{prediction.confidence}%</span>
                  </div>
                </div>
                <div className="history-time">
                  {prediction.timestamp.toLocaleTimeString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      <div className="info-panel">
        <div className="info-section">
          <h3>How Validation Works</h3>
          <p>
            After making a prediction, you have 15 seconds to see if your forecast was correct. 
            The system tracks real-time price movements and determines wins/losses based on direction:
          </p>
          <ul>
            <li><strong>Bullish:</strong> Win if price increases by 0.5%+ within 15 seconds</li>
            <li><strong>Bearish:</strong> Win if price decreases by 0.5%+ within 15 seconds</li>
            <li><strong>Sideways:</strong> Win if price stays within ±1% range</li>
          </ul>
        </div>
        
        <div className="info-section">
          <h3>Historical Context</h3>
          <p>
            The historical panel shows realistic year-long data with quarterly trends, market events, 
            and volatility patterns. This provides context for understanding current price movements 
            and making informed predictions.
          </p>
          <ul>
            <li>365 days of realistic OHLC data with volume</li>
            <li>Quarterly trend patterns and market cycles</li>
            <li>Simulated earnings events and news impacts</li>
            <li>Realistic volatility and momentum patterns</li>
            <li>Fast 15-second validation for quick feedback</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default App;